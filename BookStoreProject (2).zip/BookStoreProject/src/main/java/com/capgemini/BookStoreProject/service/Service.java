package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@org.springframework.stereotype.Service
public interface Service {

	public Users createUser(Users user) throws UserAlreadyExistException;
	
	public Users deleteUser(int userId) throws UserDoesNotExistException;
	
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException;
	
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException;
	
	public String clearCart();
	
	public Map<Integer, Book> addABookToCart(Book book);
	
	public Map<Integer, Book> removeABookFromCart(int bookId) throws BookDoesNotExistException;
	
	public Map<Integer, Book> addQuantityOfBook(int bookId) throws BookCannotBeAddedMoreAsItIsOutOfStockException;
	
	public Map<Integer, Book> decreaseQuantityOfBook(int bookId);
	
	public List<Users> listAllUsers();
	
	public List<RegisterCustomer> listAllCutomers();
	
	public Map<Integer,Book> showCart() throws NoBookInTheCartException;
}
