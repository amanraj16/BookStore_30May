package com.capgemini.BookStoreProject.exceptions;

public class NoBookInTheCartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NoBookInTheCartException(String msg)
	{
		super(msg);
	}

}
