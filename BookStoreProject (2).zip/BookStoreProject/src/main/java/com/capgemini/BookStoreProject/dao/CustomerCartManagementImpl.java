package com.capgemini.BookStoreProject.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Category;




public class CustomerCartManagementImpl implements CustomerCartManagement {
	

	
	static Map<Integer,Cart> cart = new HashMap<>();
	/*static {
		Book book = new Book();
		Category category = new Category();
		category.setCategoryId(500);
		category.setCategoryName("Comedy");
		book.setAuthorName("Shakespeare");
		book.setBookId(100);
		book.setBookImage("image.jpg");
		book.setCategory(category);
		book.setDesription("heath is welath");
		book.setIsbn("tatti");
		book.setPrice(123.56);
		book.setPublishDate(LocalDate.now());
		book.setQuantity(1);
		book.setRating(3);
		book.setTitle("Merchant Of Venice");
		cart.put(200, book);
	}*/
	
	
	@Override
	public void clearCart() {
		cart.clear();
		
	}

	
	@Override
	public Map<Integer,Cart> removeABookFromCart(int cartId) {
		Cart  = cart
		cart.remove(cartId);
		return cart;

	}

	@Override
	public Map<Integer,Book> addABookToCart(Book book) {
		
		cart.put(book.getBookId(), book);
		return cart;
	}
	
	@Override
	public Map<Integer,Book> addQuantityOfABook(int bookId) {
		Book book = cart.get(bookId);
		cart.put(bookId,book);
		return cart;
	}

	@Override
	public Book searchBook(int bookId) {
		Book book = cart.get(bookId);
		return book;
	}

	@Override
	public Map<Integer, Book> decreaseQuantityOfABook(int bookId) {
		Book book = cart.get(bookId);
		book.setQuantity(book.getQuantity()-1);
		return cart;
		}


	@Override
	public Map<Integer, Book> showAll() {
		// TODO Auto-generated method stub
		return cart;
	}


	@Override
	public double cartTotal() {
		double 
		return 0;
	}
	}
